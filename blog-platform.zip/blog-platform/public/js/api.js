const Blog = (() => {
  const TOKEN_KEY = 'blog_token';
  const USER_KEY = 'blog_user';

  function getToken() { return localStorage.getItem(TOKEN_KEY); }
  function getUser() {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  }
  function setSession(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));
  }
  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }

  async function api(path, method = 'GET', body) {
    const headers = { 'Content-Type': 'application/json' };
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  function requireAuth() {
    if (!getToken()) location.href = 'login.html';
  }

  function renderNav(activePage) {
    const slot = document.getElementById('navSlot');
    if (!slot) return;
    const user = getUser();
    slot.innerHTML = `
      <a href="index.html" class="brand"><div class="dot"></div><span>Inkwell</span></a>
      <div class="nav-links">
        <a href="index.html" ${activePage === 'feed' ? 'style="color:var(--primary)"' : ''}>Feed</a>
        ${user ? `<a href="new-post.html" class="write-btn">Write</a>` : ''}
        ${user
          ? `<span class="username-tag">@${user.username}</span><button class="logout-btn" id="navLogout">Log out</button>`
          : `<a href="login.html">Log in</a><a href="register.html">Sign up</a>`
        }
      </div>
    `;
    const logoutBtn = document.getElementById('navLogout');
    if (logoutBtn) logoutBtn.addEventListener('click', () => { clearSession(); location.href = 'index.html'; });
  }

  function timeAgo(dateStr) {
    const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
    if (diff < 60) return 'just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    if (diff < 2592000) return `${Math.floor(diff / 86400)}d ago`;
    return new Date(dateStr).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  return { getToken, getUser, setSession, clearSession, api, requireAuth, renderNav, timeAgo, escapeHtml };
})();
