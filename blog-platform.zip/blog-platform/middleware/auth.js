const { verifyToken } = require('../utils/auth');

function requireAuth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Not authenticated.' });
  }
  const decoded = verifyToken(header.slice(7));
  if (!decoded) return res.status(401).json({ error: 'Invalid or expired session.' });
  req.user = decoded; // { id, username, iat }
  next();
}

// Attaches req.user if a valid token is present, but does not block the request.
function optionalAuth(req, _res, next) {
  const header = req.headers['authorization'];
  if (header && header.startsWith('Bearer ')) {
    const decoded = verifyToken(header.slice(7));
    if (decoded) req.user = decoded;
  }
  next();
}

module.exports = { requireAuth, optionalAuth };
