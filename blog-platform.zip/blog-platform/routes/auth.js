const express = require('express');
const pool = require('../config/db');
const { hashPassword, verifyPassword, createToken } = require('../utils/auth');

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password || password.length < 6) {
      return res.status(400).json({ error: 'Username, email, and a password of at least 6 characters are required.' });
    }
    const [existing] = await pool.query(
      'SELECT id FROM users WHERE username = ? OR email = ?',
      [username, email]
    );
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Username or email is already registered.' });
    }
    const hashed = hashPassword(password);
    const [result] = await pool.query(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [username, email, hashed]
    );
    const user = { id: result.insertId, username };
    const token = createToken(user);
    res.status(201).json({ token, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Registration failed.' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
    const row = rows[0];
    if (!row || !verifyPassword(password || '', row.password)) {
      return res.status(401).json({ error: 'Incorrect username or password.' });
    }
    const user = { id: row.id, username: row.username };
    const token = createToken(user);
    res.json({ token, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed.' });
  }
});

module.exports = router;
